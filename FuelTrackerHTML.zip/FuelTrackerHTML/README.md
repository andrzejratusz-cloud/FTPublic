# Fuel Tracker — HTML

Otwórz index.html w aktualnej przeglądarce. Wszystkie style i skrypty są w pliku: nie potrzeba instalowania bibliotek, internetu ani konta.

Funkcje: miesięczny budżet wspólny dla aut; tankowania z datą, kosztem, przebiegiem, litrami i oznaczeniem pełnego baku; inne wydatki; edycja i usuwanie; kilka samochodów; obraz karty; eksport i import JSON z potwierdzeniem i walidacją.

Spalanie jest liczone między pełnymi tankowaniami i uwzględnia częściowe tankowania pomiędzy nimi. Litry pierwszego tankowania nie są liczone. Średnia jest ważona dystansem. Statystyki auta obejmują całą historię, budżet wybrany miesiąc. Dystans to różnica maksymalnego i minimalnego przebiegu tankowań. Zmiana stałego limitu wpływa na widok wszystkich miesięcy.

Dane zapisuje localStorage. Używaj tej samej przeglądarki i tej samej lokalizacji pliku. Pamięć plików lokalnych zależy od przeglądarki. Nie korzystaj z trybu prywatnego. Regularnie eksportuj kopię JSON. Kopia jest nieszyfrowana. Import zastępuje istniejące dane i obsługuje kopie tej wersji HTML, nie wcześniejszego projektu Swift.

Na iPhonie aplikacja Pliki może otworzyć HTML jako podgląd, który nie uruchamia JavaScript. Pełna obsługa w Safari na iOS wymaga udostępnienia strony jako witryny. Ta paczka jest samodzielnym plikiem HTML, nie instalowalną PWA; nie ma service workera. Do używania jako zainstalowanej aplikacji offline na iPhonie potrzebny jest kolejny etap: PWA z pierwszym wczytaniem przez HTTPS albo opakowanie natywne. Nie opublikowano strony ani nie wysłano danych na serwer.

Weryfikacja: składnia JavaScript poprawna; 18 kontroli logiki (spalanie, częściowe tankowania, średnia, wyłączenie wydatków, walidacja importu, bezpieczeństwo tekstu i format liczb); kontrola renderowania na modelu DOM i zapisu lokalnego. Nie przeprowadzono testów wizualnych w prawdziwej przeglądarce ani testów Safari na iPhonie.
